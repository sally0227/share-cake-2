export enum CakeShape {
  ROUND = 'ROUND',
  RECTANGLE = 'RECTANGLE'
}

export interface GridDimensions {
  rows: number;
  cols: number;
  total: number;
}
