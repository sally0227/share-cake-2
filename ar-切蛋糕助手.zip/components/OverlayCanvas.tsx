import React, { useRef, useEffect, useState } from 'react';
import { CakeShape, GridDimensions } from '../types';

interface OverlayCanvasProps {
  shape: CakeShape;
  slices: number;
}

const OverlayCanvas: React.FC<OverlayCanvasProps> = ({ shape, slices }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [streamError, setStreamError] = useState<string | null>(null);

  // Initialize Camera
  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: "environment" }, // Prefer back camera
            width: { ideal: 1920 },
            height: { ideal: 1080 }
          }
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      } catch (err) {
        console.error("Error accessing camera:", err);
        setStreamError("無法存取相機，請允許相機權限。");
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Animation Loop for Drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;

      // Ensure canvas matches window size
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }

      const centerX = width / 2;
      const centerY = height / 2;
      
      // Calculate shape dimensions based on screen size
      // We want some padding from the edges
      const padding = 40;
      const maxDimension = Math.min(width, height) - (padding * 2);
      
      // --- Step 1: Draw the Opaque Mask ---
      // Clear everything first
      ctx.clearRect(0, 0, width, height);
      
      // Fill the entire screen with the "cream" overlay color
      ctx.fillStyle = 'rgba(253, 251, 247, 0.95)'; // Matches Tailwind 'overlay'
      ctx.fillRect(0, 0, width, height);

      // --- Step 2: Cut out the hole (The AR Window) ---
      // 'destination-out' removes pixels from the existing canvas, making them transparent
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.fillStyle = 'black'; // Color doesn't matter for destination-out, opacity does (1.0 = fully removed)

      let rectX = 0, rectY = 0, rectW = 0, rectH = 0;
      let radius = 0;

      if (shape === CakeShape.ROUND) {
        radius = maxDimension * 0.45; // 45% of min dimension
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
        ctx.fill();
      } else {
        // Rectangle dimensions
        // Try to keep a 4:3 or 3:4 aspect ratio depending on orientation, but capped by screen
        const isPortrait = height > width;
        const rectRatio = isPortrait ? 3/4 : 4/3;
        
        if (isPortrait) {
           rectW = width - (padding * 2);
           rectH = rectW / (3/4); 
           // If height is too big, constrain by height
           if (rectH > height - 200) { // leave room for controls
             rectH = height - 300;
             rectW = rectH * (3/4);
           }
        } else {
           rectH = height - (padding * 2);
           rectW = rectH * (4/3);
        }

        rectX = centerX - rectW / 2;
        rectY = centerY - rectH / 2;

        ctx.rect(rectX, rectY, rectW, rectH);
        ctx.fill();
      }

      // --- Step 3: Draw Guides on top of the hole ---
      // Reset composite operation to draw ON TOP of the transparency
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = '#ef4444'; // Red-500
      ctx.lineWidth = 2;
      ctx.shadowBlur = 4;
      ctx.shadowColor = 'rgba(0,0,0,0.5)';

      if (shape === CakeShape.ROUND) {
        // Draw Outline
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
        ctx.strokeStyle = '#fbbf24'; // Amber-400 for outline
        ctx.stroke();

        // Draw Slices
        ctx.strokeStyle = '#ef4444'; // Red for cuts
        ctx.shadowBlur = 0; // Clear shadow for cleaner cut lines
        
        for (let i = 0; i < slices; i++) {
          const angle = (Math.PI * 2 * i) / slices - (Math.PI / 2); // Start from top (-90deg)
          const x = centerX + Math.cos(angle) * radius;
          const y = centerY + Math.sin(angle) * radius;
          
          ctx.beginPath();
          ctx.moveTo(centerX, centerY);
          ctx.lineTo(x, y);
          ctx.stroke();
        }
      } else {
        // Draw Outline
        ctx.strokeStyle = '#fbbf24'; // Amber-400
        ctx.strokeRect(rectX, rectY, rectW, rectH);

        // Calculate Grid
        // Algorithm: Try to make cells as square as possible
        // Area = r * c >= slices.
        const calculateGrid = (n: number, w: number, h: number): GridDimensions => {
           // Rule: If 10 or fewer slices, simply slice vertically (1 row, N columns)
           if (n <= 10) {
             return { rows: 1, cols: n, total: n };
           }

           // We want (w/c) approx equals (h/r) -> w*r = h*c -> r/c = h/w
           const aspectRatio = h / w;
           let bestRows = 1;
           let bestCols = n;
           let minDiff = Number.MAX_VALUE;

           for (let r = 1; r <= n; r++) {
             const c = Math.ceil(n / r);
             // Ensure we cover enough
             if (r * c < n) continue; 
             
             // Check deviation from aspect ratio
             // current cell ratio = (h/r) / (w/c) = (h*c) / (w*r). We want this close to 1 (square).
             const cellAspectRatio = (h * c) / (w * r);
             const diff = Math.abs(1 - cellAspectRatio);
             
             if (diff < minDiff) {
               minDiff = diff;
               bestRows = r;
               bestCols = c;
             }
           }
           return { rows: bestRows, cols: bestCols, total: bestRows * bestCols };
        };

        const grid = calculateGrid(slices, rectW, rectH);

        ctx.strokeStyle = '#ef4444';
        ctx.beginPath();
        
        // Vertical lines
        const cellW = rectW / grid.cols;
        for (let i = 1; i < grid.cols; i++) {
          const x = rectX + i * cellW;
          ctx.moveTo(x, rectY);
          ctx.lineTo(x, rectY + rectH);
        }

        // Horizontal lines
        const cellH = rectH / grid.rows;
        for (let i = 1; i < grid.rows; i++) {
          const y = rectY + i * cellH;
          ctx.moveTo(rectX, y);
          ctx.lineTo(rectX + rectW, y);
        }
        ctx.stroke();

        // Draw text info inside
        ctx.font = '16px sans-serif';
        ctx.fillStyle = '#ef4444';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'bottom';
        ctx.fillText(`${grid.rows} x ${grid.cols} = ${grid.total} 份`, rectX + rectW - 10, rectY + rectH - 10);
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [shape, slices]);

  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Hidden Video Element - Source of truth for camera */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover invisible" // Invisible because we only show it through the hole
        playsInline
        autoPlay
        muted
      />
      
      {/* Video Background Layer - Visible only through the hole */}
      <video
        ref={(ref) => {
            // Sync this video with the hidden one if needed, or just let it play same stream
            if (ref && videoRef.current && ref !== videoRef.current) {
                ref.srcObject = videoRef.current.srcObject;
                ref.play().catch(() => {});
            }
        }}
        className="absolute inset-0 w-full h-full object-cover"
        style={{ zIndex: 0 }}
        playsInline
        autoPlay
        muted
      />

      {/* The Canvas - Draws the mask (covering the video) and the lines */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{ zIndex: 10 }}
      />
      
      {streamError && (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-900 text-white z-50 p-6 text-center">
          <div>
            <p className="text-xl mb-2">相機無法使用</p>
            <p className="text-sm opacity-70">{streamError}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default OverlayCanvas;